package sample;

public abstract class CalcTemp {
    abstract int negate(int nr);
    abstract int add(int nr, int nr2);
    abstract int sub(int nr, int nr2);
    abstract boolean isEven(int nr);
}
